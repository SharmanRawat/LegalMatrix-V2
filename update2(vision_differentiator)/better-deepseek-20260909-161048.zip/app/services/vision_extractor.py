"""
vision_extractor.py — Two‑tier vision extractor:
1. Try Qwen2.5‑VL‑3B via Ollama (fast, high accuracy) with 10s timeout.
2. Fallback to Florence‑2 (transformers) if Qwen times out or fails.
Graceful degradation; all inference on CPU.
"""

import asyncio
import base64
import json
import logging
import re
from typing import Dict, Optional, Any

import httpx
import torch
from PIL import Image
from transformers import AutoProcessor, AutoModelForCausalLM

logger = logging.getLogger(__name__)

class VisionExtractor:
    """
    Two‑stage extractor:
    - Primary: Qwen2.5‑VL‑3B via Ollama (uses Vulkan/OpenCL, ~2.2 GB RAM)
    - Fallback: Florence‑2‑base (transformers, ~1.2 GB RAM)
    The first successful extraction is returned.
    """

    # Expected fields
    EXPECTED_KEYS = [
        "mrp", "usp", "net_quantity", "product_name",
        "manufacturer", "manufacturing_date", "expiry_date", "consumer_care"
    ]

    def __init__(
        self,
        ollama_url: str = "http://localhost:11434/api/generate",
        ollama_model: str = "qwen2.5-vl:3b",
        florence_model: str = "microsoft/Florence-2-base",
        device: str = "cpu",
        torch_dtype=torch.float32,
    ):
        self.ollama_url = ollama_url
        self.ollama_model = ollama_model
        self.florence_model = florence_model
        self.device = device
        self.torch_dtype = torch_dtype

        # Will hold Florence components if needed (lazy load)
        self._florence_processor = None
        self._florence_model = None
        self._florence_loaded = False

        # Check if Ollama is reachable (optional)
        self.ollama_available = self._check_ollama()

        # Load Florence lazily
        self._load_florence()

    def _check_ollama(self) -> bool:
        """Quickly ping Ollama to see if it's running."""
        try:
            # Use a simple GET to the root endpoint
            with httpx.Client(timeout=2.0) as client:
                resp = client.get("http://localhost:11434")
                return resp.status_code == 200
        except Exception:
            return False

    def _load_florence(self) -> None:
        """Load Florence‑2 model and processor (CPU only)."""
        try:
            logger.info("Loading Florence‑2 (fallback) on CPU...")
            self._florence_processor = AutoProcessor.from_pretrained(
                self.florence_model, trust_remote_code=True
            )
            self._florence_model = AutoModelForCausalLM.from_pretrained(
                self.florence_model,
                torch_dtype=self.torch_dtype,
                low_cpu_mem_usage=True,
                trust_remote_code=True,
            ).to(self.device)
            self._florence_model.eval()
            self._florence_loaded = True
            logger.info("Florence‑2 loaded successfully.")
        except Exception as e:
            logger.error(f"Failed to load Florence‑2: {e}")
            self._florence_loaded = False

    async def extract_from_image_path(self, image_path: str) -> Dict:
        """
        Try Qwen (Ollama) first with a 10‑second timeout.
        If that fails, use Florence‑2.
        Returns a dict with:
          - "extractions": dict of field -> {"text": value}
          - "status": "success", "error", "timeout", "fallback"
          - "method": "qwen" or "florence"
          - "raw": (optional) raw output from the model
        """
        # Try Qwen via Ollama with timeout
        try:
            logger.info(f"Attempting Qwen via Ollama for {image_path}")
            result = await asyncio.wait_for(
                self._extract_with_ollama(image_path),
                timeout=10.0
            )
            if result.get("status") == "success":
                logger.info("Qwen extraction succeeded.")
                result["method"] = "qwen"
                return result
            else:
                logger.warning(f"Qwen returned error: {result.get('error')}")
        except asyncio.TimeoutError:
            logger.warning("Qwen timed out after 10s.")
            # Fall through to Florence
        except Exception as e:
            logger.error(f"Qwen extraction raised exception: {e}")

        # Fallback to Florence
        logger.info("Falling back to Florence‑2.")
        result = await asyncio.to_thread(self._extract_with_florence, image_path)
        result["method"] = "florence"
        return result

    async def _extract_with_ollama(self, image_path: str) -> Dict:
        """Call Ollama with the image and a structured prompt."""
        if not self.ollama_available:
            return {"error": "Ollama not reachable", "status": "error"}

        # Read and encode image as base64
        try:
            with open(image_path, "rb") as f:
                img_b64 = base64.b64encode(f.read()).decode("utf-8")
        except Exception as e:
            return {"error": f"Failed to read image: {e}", "status": "error"}

        prompt = (
            "Extract the following fields from this product label image: "
            "MRP (maximum retail price), USP (unit selling price), net quantity, "
            "product name, manufacturer, manufacturing date, expiry date, consumer care details. "
            "Return ONLY a JSON object with keys: mrp, usp, net_quantity, product_name, "
            "manufacturer, manufacturing_date, expiry_date, consumer_care. "
            "Use empty strings for missing fields. No extra text."
        )

        payload = {
            "model": self.ollama_model,
            "prompt": prompt,
            "images": [img_b64],
            "stream": False,
            "format": "json",  # Ask Ollama to return JSON
        }

        async with httpx.AsyncClient(timeout=10.0) as client:
            try:
                response = await client.post(self.ollama_url, json=payload)
                if response.status_code != 200:
                    return {"error": f"Ollama HTTP {response.status_code}", "status": "error"}
                data = response.json()
                raw_text = data.get("response", "")
                # Parse JSON from response (Ollama may wrap in markdown)
                parsed = self._extract_json(raw_text)
                if not parsed:
                    return {"error": "Failed to parse JSON from Ollama", "raw": raw_text, "status": "parse_error"}
                # Build extractions dict
                extractions = {}
                for key in self.EXPECTED_KEYS:
                    val = parsed.get(key, "")
                    if val:
                        extractions[key] = {"text": str(val)}
                return {
                    "extractions": extractions,
                    "status": "success",
                    "raw": raw_text,
                }
            except httpx.TimeoutException:
                return {"error": "Ollama request timed out", "status": "timeout"}
            except Exception as e:
                return {"error": str(e), "status": "error"}

    def _extract_with_florence(self, image_path: str) -> Dict:
        """Original Florence‑2 extraction (synchronous)."""
        if not self._florence_loaded:
            return {"error": "Florence‑2 not loaded", "status": "unavailable"}

        try:
            image = Image.open(image_path).convert("RGB")
            prompt = (
                "Extract the following information from this product label image: "
                "MRP (maximum retail price), USP (unit selling price), net quantity, "
                "product name, manufacturer, manufacturing date, expiry date, consumer care details. "
                "Return the result as a JSON object with keys: mrp, usp, net_quantity, product_name, "
                "manufacturer, manufacturing_date, expiry_date, consumer_care. "
                "Only include fields that are present; use empty strings for missing ones. "
                "The output must be a valid JSON object."
            )
            inputs = self._florence_processor(
                text=prompt, images=image, return_tensors="pt"
            ).to(self.device)
            with torch.no_grad():
                generated_ids = self._florence_model.generate(
                    **inputs,
                    max_new_tokens=256,
                    do_sample=False,
                    num_beams=3,
                    early_stopping=True,
                )
            generated_text = self._florence_processor.batch_decode(
                generated_ids, skip_special_tokens=True
            )[0]
            parsed = self._extract_json(generated_text)
            if not parsed:
                return {
                    "error": "Failed to parse JSON from Florence",
                    "raw": generated_text,
                    "status": "parse_error",
                }
            extractions = {}
            for key in self.EXPECTED_KEYS:
                val = parsed.get(key, "")
                if val:
                    extractions[key] = {"text": str(val)}
            return {
                "extractions": extractions,
                "status": "success",
                "raw": generated_text,
            }
        except Exception as e:
            logger.error(f"Florence extraction failed: {e}")
            return {"error": str(e), "status": "error"}

    @staticmethod
    def _extract_json(text: str) -> Optional[Dict[str, Any]]:
        """Extract the first JSON object from the model's output."""
        match = re.search(r"\{.*\}", text, re.DOTALL)
        if not match:
            return None
        try:
            return json.loads(match.group(0))
        except json.JSONDecodeError:
            return None

# Singleton instance
_vision_extractor_instance = None

def get_vision_extractor() -> Optional[VisionExtractor]:
    """Return a singleton VisionExtractor instance."""
    global _vision_extractor_instance
    if _vision_extractor_instance is None:
        try:
            _vision_extractor_instance = VisionExtractor()
        except Exception as e:
            logger.error(f"VisionExtractor initialization failed: {e}")
            _vision_extractor_instance = None
    return _vision_extractor_instance
